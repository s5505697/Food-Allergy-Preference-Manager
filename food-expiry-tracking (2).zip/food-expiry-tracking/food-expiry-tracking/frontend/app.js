const form = document.getElementById("food-form");
const foodList = document.getElementById("food-list");
const apiBase = "http://localhost:5000/api/foods";

// Fetch and display all food items
async function fetchFoods() {
  try {
    const response = await fetch(apiBase);
    const data = await response.json();

    // Clear existing rows
    foodList.innerHTML = "";

    // Add rows to table
    data.forEach((item) => {
      const row = document.createElement("tr");
      const expiryDate = new Date(item.expiryDate);
      const isExpired = expiryDate < new Date();

      row.innerHTML = `
                <td>${item.name}</td>
                <td>${item.quantity}</td>
                <td>${expiryDate.toISOString().split("T")[0]}</td>
                <td>${item.category}</td>
                <td class="${isExpired ? "red" : "green"}">
                    ${isExpired ? "Expired" : "Valid"}
                </td>
            `;
      foodList.appendChild(row);
    });
  } catch (error) {
    console.error("Error fetching food items:", error);
  }
}

// Handle form submission
form.addEventListener("submit", async (e) => {
  e.preventDefault();

  const name = document.getElementById("name").value;
  const quantity = document.getElementById("quantity").value;
  const expiryDate = document.getElementById("expiry-date").value;
  const category = document.getElementById("category").value;

  const newFood = { name, quantity, expiryDate, category };

  try {
    await fetch(apiBase, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(newFood),
    });

    form.reset();
    fetchFoods(); // Refresh the food list
  } catch (error) {
    console.error("Error adding food item:", error);
  }
});

// Load data on page load
fetchFoods();
