const express = require("express");
const FoodItem = require("../models/foodItem");

const router = express.Router();

// GET all food items
router.get("/", async (req, res) => {
  try {
    console.log("Fetching food items from MongoDB...");
    const foodItems = await FoodItem.find(); // Fetch all food items
    console.log("Fetched food items:", foodItems); // Log the fetched data
    res.json(foodItems); // Return the fetched data
  } catch (error) {
    console.error("Error fetching food items:", error);
    res.status(500).json({ message: "Error fetching food items", error });
  }
});

// POST a new food item
router.post("/", async (req, res) => {
  try {
    console.log("Incoming request data:", req.body); // Log request data
    const { name, quantity, expiryDate, category } = req.body;

    // Validate required fields
    if (!name || !quantity || !expiryDate || !category) {
      console.log("Validation error: Missing required fields");
      return res.status(400).json({
        message:
          "All fields are required: name, quantity, expiryDate, and category.",
      });
    }

    // Create a new food item
    const newFoodItem = new FoodItem({
      name,
      quantity,
      expiryDate,
      category,
    });

    // Save the food item to the database
    const savedFoodItem = await newFoodItem.save();
    console.log("Saved food item:", savedFoodItem); // Log saved data
    res.json(savedFoodItem);
  } catch (error) {
    console.error("Error saving food item:", error);
    res.status(500).json({ message: "Error saving food item", error });
  }
});

// DELETE a food item by ID
router.delete("/:id", async (req, res) => {
  try {
    const { id } = req.params;
    console.log(`Deleting food item with ID: ${id}`);
    const deletedFoodItem = await FoodItem.findByIdAndDelete(id);
    if (!deletedFoodItem) {
      console.log("Food item not found for deletion");
      return res.status(404).json({ message: "Food item not found" });
    }
    console.log("Deleted food item:", deletedFoodItem); // Log deleted item
    res.json({ message: "Food item deleted successfully", deletedFoodItem });
  } catch (error) {
    console.error("Error deleting food item:", error);
    res.status(500).json({ message: "Error deleting food item", error });
  }
});

module.exports = router;
