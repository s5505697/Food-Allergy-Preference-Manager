const mongoose = require("mongoose");

const foodItemSchema = new mongoose.Schema({
  name: { type: String, required: true },
  quantity: { type: String, required: true },
  expiryDate: { type: Date, required: true },
  category: {
    type: String,
    required: true,
    enum: ["Meat", "Carbs", "Fish", "Veg", "Dairy"],
  },
});

const FoodItem = mongoose.model("FoodItem", foodItemSchema, "foods"); // Explicitly map to "foods" collection
console.log("FoodItem model initialized and linked to 'foods' collection");

module.exports = FoodItem;
